export * from '../list/list';
export * from '../home/home';
export * from '../ans-details/ans-details'
export * from './data';
export * from '../about/about';
